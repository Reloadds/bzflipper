package com.bzflipper;

import com.bzflipper.api.BazaarApi;
import com.bzflipper.config.FlipConfig;
import com.bzflipper.hud.Overlay;
import com.bzflipper.mc.AutoReconnect;
import com.bzflipper.mc.AutoStart;
import com.bzflipper.mc.BazaarMacro;
import com.bzflipper.mc.ScoreboardReader;
import com.bzflipper.track.ProfitTracker;
import com.bzflipper.web.WebDashboard;

import java.util.Locale;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Client entrypoint. Wires up config, the tick loop, two keybinds, and the HUD.
 *
 *   Toggle key (default \):   start/stop one flip cycle
 *   Panic key  (default END): hard-stop immediately
 */
public class BzFlipper implements ClientModInitializer {

    private FlipConfig config;
    private BazaarMacro macro;
    private Overlay overlay;
    private AutoStart autoStart;
    private AutoReconnect autoReconnect;

    private class_304 toggleKey;
    private class_304 panicKey;
    private class_304 dumpKey;
    private int skyblockLostTicks = 0;

    @Override
    public void onInitializeClient() {
        config = FlipConfig.load();
        BazaarApi api = new BazaarApi(config);
        ProfitTracker tracker = new ProfitTracker();
        macro = new BazaarMacro(config, api, tracker);
        overlay = new Overlay(macro);
        autoStart = new AutoStart(config, macro);
        autoReconnect = new AutoReconnect(config, macro::note);
        new WebDashboard(config, macro).start();   // http://localhost:{webPort}

        if (config.useApiFlips) api.start();

        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.bzflipper.toggle", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_BACKSLASH, class_304.class_11900.field_62556));

        panicKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.bzflipper.panic", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_END, class_304.class_11900.field_62556));

        dumpKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.bzflipper.dump", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_BRACKET, class_304.class_11900.field_62556));

        ClientTickEvents.END_CLIENT_TICK.register(this::onEndTick);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> overlay.render(ctx));
        // Watch chat for Bazaar limit messages (order-slot cap, daily coin limit).
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) macro.onChatMessage(message.getString());
        });

        System.out.println("[bzflipper] initialized (dryRun=" + config.dryRun + ")");
    }

    private void onEndTick(class_310 mc) {
        while (toggleKey.method_1436()) { autoStart.disarm("manual toggle"); macro.toggle(); }
        while (panicKey.method_1436()) { autoStart.disarm("panic key"); autoReconnect.cancel(); macro.stop("panic key"); }
        // Dashboard buttons (HTTP thread only sets flags; we act on the game thread).
        if (macro.webToggle.compareAndSet(true, false)) { autoStart.disarm("web toggle"); macro.toggle(); }
        if (macro.webPanic.compareAndSet(true, false)) { autoStart.disarm("web panic"); macro.stop("panic (dashboard)"); }
        // Note: dumping is automatic now (GuiDump.autoDump from the macro tick),
        // because keybinds can't fire while a Bazaar GUI is open.
        // Watchdog: kicked to a lobby/limbo mid-session? Stop cleanly and let
        // autostart walk us back (SkyBlock -> island -> resume).
        if (macro.isEnabled() && mc.field_1687 != null) {
            boolean onSb = ScoreboardReader.title(mc).toLowerCase(Locale.ROOT).contains("skyblock");
            skyblockLostTicks = onSb ? 0 : skyblockLostTicks + 1;
            if (skyblockLostTicks > 200) {   // ~10s off SkyBlock = real kick, not a transfer blip
                skyblockLostTicks = 0;
                macro.stop("left SkyBlock");
                autoStart.rearm("kicked from SkyBlock");
            }
        } else {
            skyblockLostTicks = 0;
        }

        autoReconnect.tick(mc);   // rejoin after any involuntary disconnect (runs when world == null)
        autoStart.tick(mc);
        macro.onTick(mc);
    }
}
