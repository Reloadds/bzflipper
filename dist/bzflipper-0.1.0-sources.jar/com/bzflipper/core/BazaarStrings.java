package com.bzflipper.core;

/**
 * Every Hypixel-specific piece of on-screen text the macro matches against,
 * in ONE place. The GUI is navigated by matching these substrings against item
 * names / screen titles rather than hardcoding slot numbers, so if Hypixel
 * shifts the layout the macro still works — you only ever tweak strings here.
 *
 * IMPORTANT: These are best-effort defaults. Open the Bazaar in-game and CONFIRM
 * each string matches what you actually see, then adjust. They are intentionally
 * lowercase-compared (see GuiHelper) so capitalization doesn't matter.
 */
public final class BazaarStrings {

    private BazaarStrings() {}

    // --- Screen title fragments (to detect which screen we're on) ---
    public static final String TITLE_BAZAAR      = "bazaar";        // main bazaar / category screens
    public static final String TITLE_ORDER_SETUP = "order";         // "Order options", "Buy Order", etc.

    // Search-based navigation (used by the portfolio flipper to reach any item).
    public static final String BTN_SEARCH        = "search";        // the Bazaar search button

    // --- Buttons / items we click (matched as "name contains ...") ---
    public static final String BTN_BUY_ORDER   = "buy order";
    public static final String BTN_SELL_OFFER  = "sell offer";
    public static final String BTN_CREATE_BUY  = "create buy order";
    public static final String BTN_CREATE_SELL = "create sell offer";

    // Preset amount buttons (avoid the sign-input popups)
    public static final String BTN_BUY_STACK   = "buy 1 stack";     // 64 units
    public static final String BTN_SELL_INV    = "sell inventory";  // sell everything we hold

    // Sign-input options (arbitrary amount / exact price)
    public static final String BTN_CUSTOM_AMOUNT = "custom amount";
    public static final String BTN_CUSTOM_PRICE  = "custom price";

    // Confirmation / competitive price buttons (real Bazaar wording).
    public static final String BTN_CONFIRM      = "confirm";
    public static final String BTN_BEST_PRICE   = "+0.1";           // buy:  "top order +0.1"
    public static final String BTN_BEST_SELL    = "-0.1";           // sell: "best offer -0.1"
    public static final String BTN_SPREAD_BUY   = "5% of spread";   // aggressive queue-jump (buy)
    public static final String BTN_SPREAD_SELL  = "10% of spread";  // aggressive queue-jump (sell)
    public static final String BTN_INSTASELL    = "sell instantly"; // guaranteed immediate exit
    public static final String BTN_INSTABUY     = "buy instantly";  // immediate purchase (cookie)

    // --- Booster Cookie automation ---
    public static final String TITLE_SBMENU     = "skyblock menu";
    public static final String ITEM_COOKIE      = "booster cookie";
    public static final String LORE_DURATION    = "duration";
    public static final String LORE_NOT_ACTIVE  = "not active";
    public static final String BTN_CONSUME      = "consume";

    // Primary buff-timer source: the tab-list FOOTER shows "Cookie Buff: 1d 3h"
    // (or "Not Active" when expired). Read without opening any GUI. LIVE-TUNE: open
    // your tab list on Hypixel SkyBlock and confirm the exact label wording.
    public static final String FOOTER_COOKIE    = "cookie buff";
    // The word that marks the buff as expired in the footer/lore ("Not Active").
    public static final String COOKIE_EXPIRED   = "not active";

    // Consuming a cookie is a TWO-GUI sequence. Stage 2 opens a confirmation GUI;
    // verify its TITLE contains this before clicking anything (never blind-click),
    // then click the CONFIRM slot matched by name (historically a green pane
    // labelled "Consume"). LIVE-TUNE: both strings — trigger a consume in-game
    // and read the popup's title and the confirm button's item name.
    public static final String TITLE_COOKIE_CONFIRM   = "booster cookie";
    public static final String CONFIRM_CONSUME_COOKIE = "consume";

    // On the "Confirm Buy Order" / "Confirm Sell Offer" screen, the submit button
    // is named "Buy Order" / "Sell Offer" with this in its lore ("Click to submit order!").
    public static final String LORE_SUBMIT     = "submit";

    // Manage screen
    public static final String BTN_MANAGE_ORDERS  = "manage orders";
    public static final String BTN_MANAGE_ALT     = "your bazaar orders"; // alt wording
    public static final String BTN_CLAIM          = "claim";
    public static final String BTN_CLAIM_COINS    = "claim all coins";
    public static final String BTN_CANCEL_ORDER   = "cancel order";
    public static final String BTN_GO_BACK        = "go back";

    // --- Lore parsing anchors ---
    public static final String LORE_COINS        = "coins";

    // Manage Orders screen ("Your Bazaar Orders" / "Co-op Bazaar Orders").
    public static final String TITLE_MANAGE      = "bazaar orders";

    // Grid entries are named "BUY <Item>" / "SELL <Item>".
    public static final String NAME_BUY_PREFIX   = "buy ";
    public static final String NAME_SELL_PREFIX  = "sell ";

    // Lore lines on each order in the grid.
    public static final String LORE_PRICE_UNIT   = "price per unit";
    public static final String LORE_ORDER_AMOUNT = "order amount";
    public static final String LORE_OFFER_AMOUNT = "offer amount";
    public static final String LORE_FILLED_LINE  = "filled:";
    public static final String LORE_CLAIM        = "claim";         // "Click to claim!"
    public static final String LORE_TO_CLAIM     = "items to claim"; // "you have 1,235 items to claim!"
    public static final String LORE_FILLED       = "100%";
}
