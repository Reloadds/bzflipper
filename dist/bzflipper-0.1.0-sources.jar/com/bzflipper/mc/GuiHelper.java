package com.bzflipper.mc;

import com.bzflipper.mixin.PlayerListHudAccessor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Thin, mapping-stable helpers for reading and clicking chest-style GUIs.
 * Everything the macro does to the game funnels through here, which is also the
 * seam you reimplement for the headless (Mineflayer) port.
 */
public final class GuiHelper {

    private GuiHelper() {}

    /** The chest container currently open, or null if no chest GUI is open. */
    public static class_1707 openChest(class_310 mc) {
        if (mc.field_1755 instanceof class_465<?> hs
                && hs.method_17577() instanceof class_1707 gch) {
            return gch;
        }
        return null;
    }

    /** Title of the currently open screen (lowercased), or "" if none. */
    public static String screenTitle(class_310 mc) {
        if (mc.field_1755 == null) return "";
        return mc.field_1755.method_25440().getString().toLowerCase(Locale.ROOT);
    }

    /** Number of slots that belong to the chest (excludes the player inventory). */
    public static int chestSlotCount(class_1707 chest) {
        return chest.method_17388() * 9;
    }

    /** Plain, lowercased display name of a stack. */
    public static String name(class_1799 stack) {
        if (stack == null || stack.method_7960()) return "";
        return stack.method_7964().getString().toLowerCase(Locale.ROOT);
    }

    /** Lore lines of a stack as plain lowercased strings. */
    public static List<String> lore(class_1799 stack) {
        List<String> out = new ArrayList<>();
        if (stack == null || stack.method_7960()) return out;
        class_9290 lc = stack.method_58694(class_9334.field_49632);
        if (lc == null) return out;
        for (class_2561 line : lc.comp_2401()) {
            out.add(line.getString().toLowerCase(Locale.ROOT));
        }
        return out;
    }

    /**
     * Find the first chest slot whose item name contains {@code needle}
     * (case-insensitive). Returns the slot index or -1 if not found.
     */
    public static int findSlotByName(class_310 mc, String needle) {
        class_1707 chest = openChest(mc);
        if (chest == null) return -1;
        String n = needle.toLowerCase(Locale.ROOT);
        int count = chestSlotCount(chest);
        for (int i = 0; i < count; i++) {
            class_1735 slot = chest.method_7611(i);
            if (name(slot.method_7677()).contains(n)) return i;
        }
        return -1;
    }

    /** True if any chest slot's name contains {@code needle}. */
    public static boolean hasItemNamed(class_310 mc, String needle) {
        return findSlotByName(mc, needle) >= 0;
    }

    /** First slot whose name EXACTLY equals {@code needle} (case-insensitive), or -1. */
    public static int findSlotExact(class_310 mc, String needle) {
        class_1707 chest = openChest(mc);
        if (chest == null) return -1;
        String n = needle.toLowerCase(Locale.ROOT).trim();
        int count = chestSlotCount(chest);
        for (int i = 0; i < count; i++) {
            if (name(chest.method_7611(i).method_7677()).trim().equals(n)) return i;
        }
        return -1;
    }

    /** True if a slot's name exactly equals {@code needle}. */
    public static boolean hasExactItemNamed(class_310 mc, String needle) {
        return findSlotExact(mc, needle) >= 0;
    }

    /** First slot whose name matches {@code needle} ignoring case/punctuation/
     *  symbols ("☘ Fine Peridot Gemstone" matches "Fine Peridot Gemstone"), or -1. */
    public static int findSlotNorm(class_310 mc, String needle) {
        class_1707 chest = openChest(mc);
        if (chest == null) return -1;
        String n = com.bzflipper.core.Keys.norm(needle);
        if (n.isEmpty()) return -1;
        int count = chestSlotCount(chest);
        for (int i = 0; i < count; i++) {
            if (com.bzflipper.core.Keys.norm(name(chest.method_7611(i).method_7677())).equals(n)) return i;
        }
        return -1;
    }

    /** True if a slot's name matches {@code needle} ignoring case/punctuation/symbols. */
    public static boolean hasNormItemNamed(class_310 mc, String needle) {
        return findSlotNorm(mc, needle) >= 0;
    }

    /** Click the best-matching slot: exact name → normalized (symbol-prefix
     *  tolerant) → substring. The normalized tier stops a symbol-prefixed item
     *  ("☘ Fine Peridot Gemstone") from losing to a similarly-named longer item
     *  that a bare substring match would hit first. True if clicked. */
    public static boolean clickExactName(class_310 mc, String needle) {
        int idx = findSlotExact(mc, needle);
        if (idx < 0) idx = findSlotNorm(mc, needle);
        if (idx < 0) idx = findSlotByName(mc, needle);
        return idx >= 0 && clickSlotIndex(mc, idx);
    }

    /**
     * Left-click the first chest slot whose name contains {@code needle}.
     * Returns true if something was clicked.
     */
    public static boolean clickByName(class_310 mc, String needle) {
        int idx = findSlotByName(mc, needle);
        if (idx < 0) return false;
        class_1707 chest = openChest(mc);
        if (chest == null || mc.field_1761 == null || mc.field_1724 == null) return false;
        mc.field_1761.method_2906(chest.field_7763, idx, 0, class_1713.field_7790, mc.field_1724);
        return true;
    }

    /**
     * Find the first chest slot whose name contains {@code nameNeedle} AND whose
     * lore contains {@code loreNeedle}. Used to pick our buy order vs our sell
     * offer on the Manage Orders grid (same item name, different lore). -1 if none.
     */
    public static int findSlotByNameAndLore(class_310 mc, String nameNeedle, String loreNeedle) {
        class_1707 chest = openChest(mc);
        if (chest == null) return -1;
        String n = nameNeedle.toLowerCase(Locale.ROOT);
        String l = loreNeedle.toLowerCase(Locale.ROOT);
        int count = chestSlotCount(chest);
        for (int i = 0; i < count; i++) {
            class_1799 st = chest.method_7611(i).method_7677();
            if (!name(st).contains(n)) continue;
            for (String line : lore(st)) {
                if (line.contains(l)) return i;
            }
        }
        return -1;
    }

    /** Left-click the slot matched by name+lore. True if clicked. */
    public static boolean clickByNameAndLore(class_310 mc, String nameNeedle, String loreNeedle) {
        int idx = findSlotByNameAndLore(mc, nameNeedle, loreNeedle);
        if (idx < 0) return false;
        class_1707 chest = openChest(mc);
        if (chest == null || mc.field_1761 == null || mc.field_1724 == null) return false;
        mc.field_1761.method_2906(chest.field_7763, idx, 0, class_1713.field_7790, mc.field_1724);
        return true;
    }

    /** True if the slot matched by name has any lore line containing {@code loreNeedle}. */
    public static boolean loreOfNamedContains(class_310 mc, String nameNeedle, String loreNeedle) {
        int idx = findSlotByName(mc, nameNeedle);
        if (idx < 0) return false;
        class_1707 chest = openChest(mc);
        if (chest == null) return false;
        String l = loreNeedle.toLowerCase(Locale.ROOT);
        for (String line : lore(chest.method_7611(idx).method_7677())) {
            if (line.contains(l)) return true;
        }
        return false;
    }

    /** Display name of the item in chest slot {@code idx}, or "". */
    public static String itemNameAt(class_310 mc, int idx) {
        class_1707 chest = openChest(mc);
        if (chest == null || idx < 0 || idx >= chestSlotCount(chest)) return "";
        return name(chest.method_7611(idx).method_7677());
    }

    /**
     * First chest slot whose lore contains ALL of {@code loreNeedles} (each needle
     * may match a different line). Used to find, e.g., a filled sell order. -1 if none.
     */
    public static int firstSlotWithLore(class_310 mc, String... loreNeedles) {
        class_1707 chest = openChest(mc);
        if (chest == null) return -1;
        int count = chestSlotCount(chest);
        for (int i = 0; i < count; i++) {
            List<String> lore = lore(chest.method_7611(i).method_7677());
            if (lore.isEmpty()) continue;
            boolean all = true;
            for (String needle : loreNeedles) {
                String n = needle.toLowerCase(Locale.ROOT);
                boolean found = false;
                for (String line : lore) if (line.contains(n)) { found = true; break; }
                if (!found) { all = false; break; }
            }
            if (all) return i;
        }
        return -1;
    }

    /** Count chest slots whose lore contains {@code loreNeedle}. */
    public static int countSlotsWithLore(class_310 mc, String loreNeedle) {
        class_1707 chest = openChest(mc);
        if (chest == null) return 0;
        String n = loreNeedle.toLowerCase(Locale.ROOT);
        int count = chestSlotCount(chest), hits = 0;
        for (int i = 0; i < count; i++) {
            for (String line : lore(chest.method_7611(i).method_7677())) {
                if (line.contains(n)) { hits++; break; }
            }
        }
        return hits;
    }

    /** Lowercased names of every non-empty chest slot (excludes player inventory). */
    public static Set<String> collectNames(class_310 mc) {
        Set<String> out = new HashSet<>();
        class_1707 chest = openChest(mc);
        if (chest == null) return out;
        int count = chestSlotCount(chest);
        for (int i = 0; i < count; i++) {
            String nm = name(chest.method_7611(i).method_7677());
            if (!nm.isEmpty()) out.add(nm);
        }
        return out;
    }

    /** Names of items in the player-inventory portion of the open chest GUI. */
    public static Set<String> playerInventoryNames(class_310 mc) {
        Set<String> out = new HashSet<>();
        class_1707 chest = openChest(mc);
        if (chest == null) return out;
        int container = chestSlotCount(chest);
        int total = chest.field_7761.size();
        for (int i = container; i < total; i++) {
            String nm = name(chest.method_7611(i).method_7677());
            if (!nm.isEmpty()) out.add(nm);
        }
        return out;
    }

    /** Read the live bazaar tax fraction from the product page's "Sell Instantly"
     *  lore ("current tax: 1.1%"). Returns NaN if not visible. */
    public static double readTaxFraction(class_310 mc) {
        int idx = findSlotByName(mc, "sell instantly");
        if (idx < 0) return Double.NaN;
        class_1707 chest = openChest(mc);
        if (chest == null) return Double.NaN;
        for (String line : lore(chest.method_7611(idx).method_7677())) {
            if (!line.contains("tax")) continue;
            Matcher m = NUMBER.matcher(line);
            if (m.find()) {
                try {
                    return Double.parseDouble(m.group(1).replace(",", "")) / 100.0;
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return Double.NaN;
    }

    /** First player-inventory slot (handler index) whose item name contains
     *  {@code needle}, or -1. Searches only the player section of the open GUI. */
    public static int findPlayerSlotByName(class_310 mc, String needle) {
        class_1707 chest = openChest(mc);
        if (chest == null) return -1;
        String n = needle.toLowerCase(Locale.ROOT);
        int container = chestSlotCount(chest);
        int total = chest.field_7761.size();
        for (int i = container; i < total; i++) {
            if (name(chest.method_7611(i).method_7677()).contains(n)) return i;
        }
        return -1;
    }

    /** Swap a handler slot with a hotbar slot (0–8). True if the click was sent. */
    public static boolean swapToHotbar(class_310 mc, int slotIdx, int hotbarIdx) {
        class_1707 chest = openChest(mc);
        if (chest == null || mc.field_1761 == null || mc.field_1724 == null) return false;
        mc.field_1761.method_2906(chest.field_7763, slotIdx, hotbarIdx, class_1713.field_7791, mc.field_1724);
        return true;
    }

    // ---- Cookie-consume seam (headless port reimplements these) --------------
    // These four are the ONLY new player-world capabilities the cookie refresh
    // needs beyond chest clicks. Kept here on the seam so the Mineflayer port has
    // a single place to reimplement "read tab footer / select hotbar slot / use
    // held item", instead of raw Minecraft calls leaking into the state machine.
    //
    // MAPPING NOTE (Yarn 1.21.11, resolved against the mappings, not memory):
    //   PlayerInventory.getSelectedSlot() = method_67532, setSelectedSlot(int) =
    //   method_61496; ClientPlayerInteractionManager.interactItem(player, hand) =
    //   method_2919; PlayerListHud.footer = field_2154 (via PlayerListHudAccessor).

    /** Plain text of the tab-list FOOTER (lowercased), or "" if unavailable. The
     *  SkyBlock "Cookie Buff: …" line lives here; readable with no GUI open. */
    public static String tablistFooter(class_310 mc) {
        if (mc.field_1705 == null) return "";
        var hud = mc.field_1705.method_1750();
        if (hud == null) return "";
        class_2561 footer = ((PlayerListHudAccessor) hud).getFooter();
        return footer == null ? "" : footer.getString().toLowerCase(Locale.ROOT);
    }

    /** Currently selected hotbar slot (0–8), or -1 if unavailable. */
    public static int selectedHotbarSlot(class_310 mc) {
        return mc.field_1724 == null ? -1 : mc.field_1724.method_31548().method_67532();
    }

    /** Select a hotbar slot (0–8) as the main hand. No-op if out of range. */
    public static void setSelectedHotbarSlot(class_310 mc, int slot) {
        if (mc.field_1724 != null && slot >= 0 && slot <= 8) {
            mc.field_1724.method_31548().method_61496(slot);
        }
    }

    /** Hotbar slot (0–8) holding an item whose name contains {@code needle}, or -1.
     *  Reads the real player inventory, so it works with or without a GUI open. */
    public static int hotbarSlotOf(class_310 mc, String needle) {
        if (mc.field_1724 == null) return -1;
        String n = needle.toLowerCase(Locale.ROOT);
        for (int i = 0; i <= 8; i++) {
            if (name(mc.field_1724.method_31548().method_5438(i)).contains(n)) return i;
        }
        return -1;
    }

    /** True if the real player inventory (hotbar + main, 0–35) holds an item whose
     *  name contains {@code needle}. Works with NO GUI open (reads getInventory). */
    public static boolean playerHasItem(class_310 mc, String needle) {
        if (mc.field_1724 == null) return false;
        String n = needle.toLowerCase(Locale.ROOT);
        for (int i = 0; i <= 35; i++) {
            if (name(mc.field_1724.method_31548().method_5438(i)).contains(n)) return true;
        }
        return false;
    }

    /** First EMPTY hotbar slot (0–8), or -1 if the whole hotbar is occupied.
     *  Used to move a cookie into the hotbar WITHOUT displacing gear. */
    public static int firstEmptyHotbarSlot(class_310 mc) {
        if (mc.field_1724 == null) return -1;
        for (int i = 0; i <= 8; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960()) return i;
        }
        return -1;
    }

    /**
     * Right-click (use) the held item — the world-interaction that opens the
     * cookie's consume-confirmation GUI.
     *
     * GUARD (#2): calling interactItem() directly IS the vanilla "use item in air"
     * branch (doItemUse routes block hits to interactBlock and only otherwise to
     * interactItem), so it is NOT interpreted as a block interaction. We ALSO snap
     * the pitch straight up first so nothing placeable/interactable is under the
     * crosshair — belt and suspenders — and restore look afterward.
     *
     * @return true if the use packet was sent.
     */
    public static boolean useHeldItem(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1761 == null) return false;
        float yaw = mc.field_1724.method_36454(), pitch = mc.field_1724.method_36455();
        mc.field_1724.method_36457(-90f);   // aim at sky: never target a block
        try {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        } finally {
            mc.field_1724.method_36457(pitch);   // restore look; macro navigates via GUIs, not aim
            mc.field_1724.method_36456(yaw);
        }
        return true;
    }

    /** True if a confirmation-style HandledScreen (any non-chest handled screen, or
     *  a chest) is open whose title contains {@code titleNeedle}. */
    public static boolean handledScreenTitleContains(class_310 mc, String titleNeedle) {
        return mc.field_1755 instanceof class_465<?>
                && screenTitle(mc).contains(titleNeedle.toLowerCase(Locale.ROOT));
    }

    /** Count empty slots in the player inventory portion of the open chest GUI. */
    public static int freeInventorySlots(class_310 mc) {
        class_1707 chest = openChest(mc);
        if (chest == null) return 99;   // unknown -> don't cap
        int container = chestSlotCount(chest);
        int total = chest.field_7761.size();
        int free = 0;
        for (int i = container; i < total; i++) {
            if (chest.method_7611(i).method_7677().method_7960()) free++;
        }
        return free;
    }

    /** Left-click a specific chest slot index. True if clicked. */
    public static boolean clickSlotIndex(class_310 mc, int idx) {
        class_1707 chest = openChest(mc);
        if (chest == null || idx < 0 || idx >= chestSlotCount(chest)
                || mc.field_1761 == null || mc.field_1724 == null) return false;
        mc.field_1761.method_2906(chest.field_7763, idx, 0, class_1713.field_7790, mc.field_1724);
        return true;
    }

    // Matches numbers like "1,234,567.8" possibly followed by "coins".
    private static final Pattern NUMBER = Pattern.compile("([0-9][0-9,]*\\.?[0-9]*)");

    /**
     * Pull the first coin value out of the lore lines of the slot named
     * {@code needle}. Returns NaN if not found. Used for the HUD and margin math.
     */
    public static double readCoinPrice(class_310 mc, String itemNeedle, String loreAnchor) {
        int idx = findSlotByName(mc, itemNeedle);
        if (idx < 0) return Double.NaN;
        class_1703 h = openChest(mc);
        if (h == null) return Double.NaN;
        for (String line : lore(h.method_7611(idx).method_7677())) {
            if (loreAnchor == null || line.contains(loreAnchor.toLowerCase(Locale.ROOT))) {
                Matcher m = NUMBER.matcher(line);
                if (m.find()) {
                    try {
                        return Double.parseDouble(m.group(1).replace(",", ""));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
        return Double.NaN;
    }
}
