package com.bzflipper.mc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

/**
 * Reads the SkyBlock sidebar (scoreboard) as plain text lines. SkyBlock renders
 * each line as a team prefix + suffix on a hidden entry, so we reconstruct the
 * visible text by decorating each entry with its team.
 *
 * MAPPING NOTE: scoreboard APIs shift between versions. If this fails to compile,
 * the likely culprits are getScoreboardEntries / getScoreHolderTeam names.
 */
public final class ScoreboardReader {

    private ScoreboardReader() {}

    public static List<String> sidebarLines(class_310 mc) {
        List<String> out = new ArrayList<>();
        if (mc.field_1687 == null) return out;
        try {
            class_269 sb = mc.field_1687.method_8428();
            class_266 obj = sb.method_1189(class_8646.field_45157);
            if (obj == null) return out;

            for (class_9011 entry : sb.method_1184(obj)) {
                String owner = entry.comp_2127();
                class_268 team = sb.method_1164(owner);
                String line = owner;
                if (team != null) {
                    line = team.method_1144().getString() + owner + team.method_1136().getString();
                }
                out.add(stripFormatting(line));
            }
        } catch (Throwable t) {
            System.err.println("[bzflipper] scoreboard read failed: " + t);
        }
        return out;
    }

    /** The sidebar title line (usually "SKYBLOCK"), or "" if unavailable. */
    public static String title(class_310 mc) {
        if (mc.field_1687 == null) return "";
        class_266 obj = mc.field_1687.method_8428()
                .method_1189(class_8646.field_45157);
        return obj == null ? "" : stripFormatting(obj.method_1114().getString());
    }

    private static String stripFormatting(String s) {
        return s.replaceAll("(?i)§[0-9A-FK-OR]", "").trim();
    }
}
