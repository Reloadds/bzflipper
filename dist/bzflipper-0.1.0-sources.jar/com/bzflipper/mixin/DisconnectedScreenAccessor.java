package com.bzflipper.mixin;

import net.minecraft.class_419;
import net.minecraft.class_9812;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes the private {@code info} field of the disconnect screen so we can read
 * WHY we were kicked and decide whether to reconnect.
 *
 * MAPPING NOTE (verified against Yarn 1.21.11): {@link class_419} holds
 * a {@link class_9812 info} field; {@code info.reason()} is the reason
 * Text shown to the player. If a future mapping renames the field, change the
 * {@code @Accessor} argument below.
 */
@Mixin(class_419.class)
public interface DisconnectedScreenAccessor {

    @Accessor("info")
    class_9812 getInfo();
}
